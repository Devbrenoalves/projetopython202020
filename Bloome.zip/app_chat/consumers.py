from django.shortcuts import get_object_or_404, HttpResponse
import json
from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer

# --- Import from own Apps ---------
from .models import GroupMessage, ChatGroup
from app_account.models import Notification

# ===== NOTIFICATION CONSUMER ==== 
class NotificationConsumer(WebsocketConsumer):
    def connect(self):

        return self.accept()

# ===== ROOM or GROUP CHAT CONSUMER =====
class RoomChatConsumer(WebsocketConsumer):
    async def connect(self):
        if not self.user.is_authenticated:            
            await self.close()
            return
           
        return self.accept()
    
    def disconnect(self, code):
        pass
    
    def receive(self, text_data):
        pass

